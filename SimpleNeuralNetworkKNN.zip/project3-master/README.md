# Project7

'''
conda install scikit-learn
'''


