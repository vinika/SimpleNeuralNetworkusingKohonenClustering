# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 15:25:41 2019

@author: Gerry Dozier
"""
import os
import random
import sys
import math
import time
import numpy as np
import sklearn
<<<<<<< HEAD
=======
import array as arr
import pandas as pd
>>>>>>> 94335cf5ca7bbc72afd94673535ee2de1b814e07
from random import sample
from sklearn.svm import SVC
from sklearn.datasets import load_iris
from sklearn import random_projection
from sklearn import svm
from sklearn import datasets
from sklearn import random_projection
from sklearn.model_selection import train_test_split
<<<<<<< HEAD
=======
from sklearn.neural_network import MLPClassifier
>>>>>>> 94335cf5ca7bbc72afd94673535ee2de1b814e07
#split data set into train and test sets

import matplotlib.pyplot as plt
#import csv
#import numpy as np
from mpl_toolkits.mplot3d import Axes3D


class aGaussianKernel:
    def __init__(self, target, desired_output):
        self.target = target
        self.desired_output = desired_output     

    def fire_strength(self, q, sigma):
        sum_squared = 0.0
        for i in range(0,len(q)):
            sum_squared += math.pow((q[i] - self.target[i]),2.0)
        #print("FS Sum_Squared = " + str(sum_squared))
        return math.exp(-sum_squared/(2.0*pow(sigma,2.0)))
        
    def print_gaussian_kernel(self):
        print("Target = ", self.target, " Desired Output = " + str(self.desired_output))
    
         

class RBF(StationaryKernelMixin, NormalizedKernelMixin, Kernel):
    """Radial-basis function kernel (aka squared-exponential kernel).
    The RBF kernel is a stationary kernel. It is also known as the
    "squared exponential" kernel. It is parameterized by a length-scale
    parameter length_scale>0, which can either be a scalar (isotropic variant
    of the kernel) or a vector with the same number of dimensions as the inputs
    X (anisotropic variant of the kernel). The kernel is given by:
    k(x_i, x_j) = exp(-1 / 2 d(x_i / length_scale, x_j / length_scale)^2)
    This kernel is infinitely differentiable, which implies that GPs with this
    kernel as covariance function have mean square derivatives of all orders,
    and are thus very smooth.
    .. versionadded:: 0.18
    Parameters
    ----------
    length_scale : float or array with shape (n_features,), default: 1.0
        The length scale of the kernel. If a float, an isotropic kernel is
        used. If an array, an anisotropic kernel is used where each dimension
        of l defines the length-scale of the respective feature dimension.
    length_scale_bounds : pair of floats >= 0, default: (1e-5, 1e5)
        The lower and upper bound on length_scale
    """
    def __init__(self, length_scale=1.0, length_scale_bounds=(1e-5, 1e5)):
        self.length_scale = length_scale
        self.length_scale_bounds = length_scale_bounds

    @property
    def anisotropic(self):
        return np.iterable(self.length_scale) and len(self.length_scale) > 1

    @property
    def hyperparameter_length_scale(self):
        if self.anisotropic:
            return Hyperparameter("length_scale", "numeric",
                                  self.length_scale_bounds,
                                  len(self.length_scale))
        return Hyperparameter(
            "length_scale", "numeric", self.length_scale_bounds)

    def __call__(self, X, Y=None, eval_gradient=False):
        """Return the kernel k(X, Y) and optionally its gradient.
        Parameters
        ----------
        X : array, shape (n_samples_X, n_features)
            Left argument of the returned kernel k(X, Y)
        Y : array, shape (n_samples_Y, n_features), (optional, default=None)
            Right argument of the returned kernel k(X, Y). If None, k(X, X)
            if evaluated instead.
        eval_gradient : bool (optional, default=False)
            Determines whether the gradient with respect to the kernel
            hyperparameter is determined. Only supported when Y is None.
        Returns
        -------
        K : array, shape (n_samples_X, n_samples_Y)
            Kernel k(X, Y)
        K_gradient : array (opt.), shape (n_samples_X, n_samples_X, n_dims)
            The gradient of the kernel k(X, X) with respect to the
            hyperparameter of the kernel. Only returned when eval_gradient
            is True.
        """
        X = np.atleast_2d(X)
        length_scale = _check_length_scale(X, self.length_scale)
        if Y is None:
            dists = pdist(X / length_scale, metric='sqeuclidean')
            K = np.exp(-.5 * dists)
            # convert from upper-triangular matrix to square matrix
            K = squareform(K)
            np.fill_diagonal(K, 1)
        else:
            if eval_gradient:
                raise ValueError(
                    "Gradient can only be evaluated when Y is None.")
            dists = cdist(X / length_scale, Y / length_scale,
                          metric='sqeuclidean')
            K = np.exp(-.5 * dists)

        if eval_gradient:
            if self.hyperparameter_length_scale.fixed:
                # Hyperparameter l kept fixed
                return K, np.empty((X.shape[0], X.shape[0], 0))
            elif not self.anisotropic or length_scale.shape[0] == 1:
                K_gradient = \
                    (K * squareform(dists))[:, :, np.newaxis]
                return K, K_gradient
            elif self.anisotropic:
                # We need to recompute the pairwise dimension-wise distances
                K_gradient = (X[:, np.newaxis, :] - X[np.newaxis, :, :]) ** 2 \
                    / (length_scale ** 2)
                K_gradient *= K[..., np.newaxis]
                return K, K_gradient
        else:
            return K

    def __repr__(self):
        if self.anisotropic:
            return "{0}(length_scale=[{1}])".format(
                self.__class__.__name__, ", ".join(map("{0:.3g}".format,
                                                   self.length_scale)))
        else:  # isotropic
            return "{0}(length_scale={1:.3g})".format(
                self.__class__.__name__, np.ravel(self.length_scale)[0])


        
class aSimpleNeuralNetwork:
    def __init__(self,dataset_file_name,num_of_inputs,num_of_outputs):
        self.dataset_file_name = dataset_file_name
        self.num_of_inputs = num_of_inputs
        self.num_of_outputs = num_of_outputs
        self.training_instance = []
        self.data = []
        self.neuron = []
        self.sigma = 0
        self.tp = 0         # true positive
        self.tn = 0         # true negative
        self.fp = 0         # false positive
        self.fn = 0         # false negative
<<<<<<< HEAD
        
        
=======
<<<<<<< HEAD

     
=======
        self.target_arr = []
        self.output_arr = []
        self.target_train = []
        self.target_test = []
        self.desValue_test = []
        self.desValue_train = []
        self.desValue_val = []
        self.target_val = []
        self.train_data = []
>>>>>>> 94335cf5ca7bbc72afd94673535ee2de1b814e07
>>>>>>> ce3721426dc0e807cf93d0f218bb797df5a9b9ce
        with open(self.dataset_file_name, "r") as dataset_file:
            for line in dataset_file:
                line = line.strip().split(" ")
                self.data.append([float(x) for x in line[0:]])
                
        for i in range(len(self.data)):
            temp = aGaussianKernel(self.data[i][:self.num_of_inputs],self.data[i][self.num_of_inputs])
            self.neuron.append(temp)
<<<<<<< HEAD
         
            
        self.train_data, self.validate, self.test = np.split(self.data, [int(.8*len(self.data)), int(.9*len(self.data))])
        
#        self.data_out_forward = forward_pass(self)
#        self.data_out_backward = backward_pass(self)
#        self.data_out_EBP = error_backpropagation(self)

    def sigmoid(net):
        out = 1/(1+np.exp(-net))
        return out
        
    def net_sum(w,x):
        net = w*x
        return net
        
#    def del_w_component(net,w):
#        del_w = net/w#del_net/del_w
#        return del_w
    
    def forward_pass():#self):
        #Forward Pass
        for i in range(0,1,1):#len(self.data)):
            net = 1
            #net[i] = net_sum(w[i],x[i])
            o = 1
            #o[i] = sigmoid(net[i])
        
    def backward_pass():#self):
        #Backward Pass
        for i in range(0,1,1):#len(self.data)):
            w[i] = 1
            #w = 1
        
    def error_backpropagation():#self):
        #Error Back-Propagation
        for i in range(0,1,1):#len(self.data),1):
            error_w[i] = 1
        
        
#        self.data_train, self.data_test, self.target_train, self.target_test = train_test_split(self.data, self.target, test_size = 0.1, random_state = 1)
#        self.data_train, self.data_val, self.target_train, self.target_val = train_test_split(data_train, target_train, test_size = 0.1, random_state = 1)
<<<<<<< HEAD
        
        
        
    def kohonen_clustering():
        for i in range(0,1,1):#len(self.data),1):
            clusters[i] = 1
            kohonen_weights[i] = 1
        return clusters
        
    def RBFNN():
        i = 1
        j = 1
        x[i] = 1
        x[j] = 1
        d = 1
        n = x[i]
        m = x[j]
        RBFNN_kernel[n][m] = np.exp(-1/(2*d*((x[i]/l,x[j]/l))))
        RBFNN_outputs = 1 
        #for i in range(0,len(data),1)
            #z_input = z[p]
            #u_mean = u[j]
            #linear_function = (z_input-u_mean)**2
            #gaussian_function = np.exp(-(((z_input-u_mean))**2)/(2*(sigma**2)))
            #RBFNN_outputs += w[i]*y[i]
        for j in range(0,1,1):
            sigma[j] = d_max/np.sqrt(J)
            w[k] = np.inv(np.transpose(phi)*phi)*np.transpose(phi)*t[k]
        return RBFNN_outputs
        
    #The accuracy of the RBFNN is influenced by the number of basis functions used, the location of the basis functions, and the width of the receptive field. Training a RBFNN can be don using algorithms that adapt only the weights between the hidden and output layers, algorithms that adapt both weights, centers, and deviations, or other algorithms. 
    #A training algorithm that utilizes Kohonen unsupervised learning to develop the clustering can be used \cite{Engelbrecht}.%pg. 79
    #The K-means algorithm can be used . 
    #
        
=======
      
    
=======
            self.target_arr.append(self.neuron[i].target)
            self.output_arr.append(self.neuron[i].desired_output)
                                      
        self.target_train, self.target_test, self.desValue_train, self.desValue_test = train_test_split(self.target_arr, self.output_arr, test_size = 0.1, random_state = 1)
        self.target_train, self.target_val, self.desValue_train, self.desValue_val = train_test_split(self.target_train, self.desValue_train, test_size = 0.111, random_state = 1)
    
        self.target_train = np.array(self.target_train)
        self.desValue_train = np.array(self.desValue_train)
      #  self.desValue_train.flatten('F')
        self.desValue_train = self.desValue_train.astype('int')
        
        
>>>>>>> 94335cf5ca7bbc72afd94673535ee2de1b814e07
>>>>>>> ce3721426dc0e807cf93d0f218bb797df5a9b9ce
    def set_sigma(self, sigma):
        self.sigma = sigma
        
    def distance_squared(self,x,y):
        dist_sqrd = 0
        for i in range(len(x)):
            dist_sqrd += (x[i] - y[i])**2
        return dist_sqrd    
    
    def train(self):
        dmax = 0
        dist_squared = 0
<<<<<<< HEAD
        for i in range(len(self.train_data)-1):
            for j in range((i+1),len(self.train_data)):
                dist_squared = self.distance_squared(self.neuron[i].target,self.neuron[j].target)
                if dmax < dist_squared:
                    dmax = dist_squared
        self.sigma = math.sqrt(dmax)
        print("dmax =", self.sigma)
        print("total training data: ", len(self.train_data))
<<<<<<< HEAD
        
    
    
=======
                
=======
        """
        for i in range(len(self.target_train)-1):
            for j in range((i+1),len(self.target_train)):
                dist_squared = self.distance_squared(self.neuron[i].target,self.neuron[j].target)
                if dmax < dist_squared:
                    dmax = dist_squared
                if self.neuron[i].desired_output > 0.5:
                    self.neuron[i].desired_output = 1
                else:
                    self.neuron[i].desired_output = -1
        self.sigma = math.sqrt(dmax)
        print("dmax =", self.sigma)
        """
        
        self.target_train.reshape(-1,2)
     #   np.reshape(self.desValue_train,(-1, 1))
        clf = MLPClassifier(solver='sgd', activation = 'logistic', alpha=1e-5, hidden_layer_sizes=(5,2), random_state=1)
        clf.fit(self.target_train, self.desValue_train)
        clf.predict(self.target_test[0])
        print("total training data: ", len(self.target_train))
        

    """
    def train(self):
        dmax = 0
        dist_squared = 0
        weight1 = random.random()
        print("weight:",weight1)
        weight2 = random.random()
        net = 0
        Out = 0
        sq_error = 0
        err_gradient = 0
        f_out = 0
        f_back = 0
        t = 0
        for i in range(len(self.train_data)):
            net += (self.neuron[i].target[0]*weight1 + self.neuron[i].target[1]*weight2)
            try:
                f_net = 1/(1+math.exp(-net))
            except OverflowError:
                f_net = 0
            Out += f_net
        sq_error = self.neuron[i].desired_output - Out

        for j in range(len(self.train_data)):
            f_out = 1/(1+math.exp(-Out))
            f_back = f_out*(1-f_out)
            t += 1
            err_gradient = f_back*(self.neuron[j].desired_output - Out)
        print("error gradient: ", err_gradient)
            
    """
            



>>>>>>> 94335cf5ca7bbc72afd94673535ee2de1b814e07
>>>>>>> ce3721426dc0e807cf93d0f218bb797df5a9b9ce
    def check(self,query):
        sum_fire_strength = 0
        sum_fire_strength_x_desired_output = 0
        for i in range(len(self.neuron)):
            the_fire_strength = self.neuron[i].fire_strength(query,self.sigma)
            sum_fire_strength_x_desired_output += the_fire_strength * self.neuron[i].desired_output
            sum_fire_strength += the_fire_strength
        if (sum_fire_strength == 0.0):
            sum_fire_strength = 0.000000001               # to prevent divide by zero
        return sum_fire_strength_x_desired_output/sum_fire_strength
<<<<<<< HEAD
    
    def test_model(self,number_of_test_cases):
        for i in range(number_of_test_cases):
            test_case = []
            sum_squared_error = 0
            x = random.uniform(-100.0,100.0)
            y = random.uniform(-100.0,100.0)
            test_case.append(x)
            test_case.append(y)
=======
<<<<<<< HEAD
 
    def test_model(self,number_of_test_cases):
        print()
        for i in range(len(self.test)-1):
            for j in range((i+1), len(self.test)):
                sum_squared_error = 0
=======
    
    def test_model(self,number_of_test_cases):
        for i in range(number_of_test_cases-1):
#            test_case = []
            test_case = self.neuron[i].target
            sum_squared_error = 0
            
            x = self.neuron[i].target[0]
            y = self.neuron[i].target[1]
>>>>>>> 94335cf5ca7bbc72afd94673535ee2de1b814e07
#            x = random.uniform(-100.0,100.0)
#            y = random.uniform(-100.0,100.0)
#            test_case.append(x)
#            test_case.append(y)
<<<<<<< HEAD
                x = self.neuron[i].target
                y = self.neuron[j].target
>>>>>>> ce3721426dc0e807cf93d0f218bb797df5a9b9ce
            
            x2y2 = x**2 + y**2
            SchafferF6 = 0.5 + (math.sin(math.sqrt(x2y2))**2 - 0.5) / (1+0.001*x2y2)**2
            
            test_instance_result = self.check(test_case)
            sum_squared_error += (test_instance_result - SchafferF6)**2
            self.calculate_statistics(test_instance_result,SchafferF6)
=======
            
            x2y2 = x**2 + y**2
            SchafferF6 = 0.5 + (math.sin(math.sqrt(x2y2))**2 - 0.5) / (1+0.001*x2y2)**2

            test_instance_result = self.check(test_case)
            sum_squared_error += (test_instance_result - SchafferF6)**2
            self.calculate_statistics(test_instance_result,SchafferF6)
        print("num test cases: ", number_of_test_cases)
>>>>>>> 94335cf5ca7bbc72afd94673535ee2de1b814e07
        return (sum_squared_error/number_of_test_cases)
    
    
    def calculate_statistics(self, test_instance_result, SchafferF6):
       # print("in calculate", test_instance_result, " ", SchafferF6)
        if ((test_instance_result > 0.5) and (SchafferF6 > 0.5)):
            self.tp += 1
        if ((test_instance_result <= 0.5) and (SchafferF6 <= 0.5)):
            self.tn += 1
        if ((test_instance_result > 0.5) and (SchafferF6 <= 0.5)):
            self.fp += 1
        if ((test_instance_result <= 0.5) and (SchafferF6 > 0.5)):
            self.fn += 1
           
    def plot_model(self, number_of_test_cases, lb, ub):
        test_case_x = []
        test_case_y = []
        test_case_z = []
        
        schafferF6_x = []
        schafferF6_y = []
        schafferF6_z = []
        
        for i in range(number_of_test_cases):
            x = random.uniform(lb,ub)
            y = random.uniform(lb,ub)
            
            test_case_x.append(x)
            test_case_y.append(y)
            schafferF6_x.append(x)
            schafferF6_y.append(y)
            
            test_case = []
            test_case.append(x)
            test_case.append(y)
            #print("test case: ",test_case)
            test_case_z.append(self.check(test_case))
            
            x2y2 = x**2 + y**2
            SchafferF6 = 0.5 + (math.sin(math.sqrt(x2y2))**2 - 0.5) / (1+0.001*x2y2)**2
            schafferF6_z.append(SchafferF6)
            
        fig = plt.figure()
        ax1 = fig.add_subplot(1,1,1,projection='3d')
        ax1.scatter(test_case_x,test_case_y,test_case_z,edgecolor='white')#,cmap='plasma',edgecolor='white')
        plt.title("Simple Neural Network")
        ax1.set_zlim3d(0.2,1.0)
        plt.show()
        
        fig = plt.figure()
        ax2 = fig.add_subplot(1,1,1,projection='3d')
        ax2.scatter(schafferF6_x,schafferF6_y,schafferF6_z,edgecolor='white')#,edgecolors=colors)#cmap='ocean')#,edgecolor='white')
        plt.title("SchafferF6")
        ax2.set_zlim3d(0.2,1.0)
        plt.show()
            
    def print_training_set(self):
        print(self.train_data)
        print(len(self.train_data))
    
    def print_neurons(self):
        for i in range(len(self.neuron)):
            self.neuron[i].print_gaussian_kernel()

    def print_statistics(self):
        accuracy = (self.tp + self.tn)/(self.tp + self.tn + self.fp + self.fn)
        recall   = self.tp/(self.tp + self.fn + 0.00001)
        precision = self.tp/(self.tp + self.fp + 0.00001)
        f1        = 2*(precision * recall)/(precision + recall + 0.00001)
        print("Accuracy:  ", accuracy)
        print("Recall:    ", recall)
        print("Precision: ", precision)
        print("F1:        ", f1)

class dataset_generator:
    def __init__(self,filename,lb,ub):
        self.filename = filename
        self.lb = lb
        self.ub = ub
    
    def generate_dataset(self,number_of_training_instances):
        dataset_file = open(self.filename, 'w')
        for i in range (number_of_training_instances):
            x = random.uniform(self.lb,self.ub)
            y = random.uniform(self.lb,self.ub)
            x2y2 = x**2 + y**2
            dataset_file.write(str(x) + " " + str(y) + " " + str(0.5 + (math.sin(math.sqrt(x2y2))**2 - 0.5) / (1+0.001*x2y2)**2) + "\n")
        dataset_file.close()

lower_bound = -100.0
upper_bound =  100.0

dg = dataset_generator('Project3_Dataset_v2.txt',lower_bound,upper_bound)
dg.generate_dataset(1000)

#simple_neural_network = aSimpleNeuralNetwork('C:\\Users\\alj0032\\gitlab\\project3\\Project3_Dataset_v1.txt',2,1)
simple_neural_network = aSimpleNeuralNetwork('Project3_Dataset_v1.txt',2,1)
#simple_neural_network = aSimpleNeuralNetwork('C:\Users\alj0032\gitlab\project3\Project3_Dataset_v1.txt',2,1)

#data_out_forward = simple_neural_network.forward_pass()
#data_out_backward = simple_neural_network.backward_pass()
#data_out_EBP = simple_neural_network.error_backpropagation()

simple_neural_network.forward_pass()#simple_neural_network.data)
simple_neural_network.backward_pass()#simple_neural_network.data)
simple_neural_network.error_backpropagation()#simple_neural_network.data)

simple_neural_network.train()
simple_neural_network.set_sigma(10)

<<<<<<< HEAD
simple_neural_network.distance_squared()
simple_neural_network.test_model()

print("Model Test AMSE: ", simple_neural_network.test_model(len(simple_neural_network.test)))
=======
<<<<<<< HEAD
print("Model Test AMSE: ", simple_neural_network.test_model(1000))
=======
print("Model Test AMSE: ", simple_neural_network.test_model(len(simple_neural_network.target_test)))

>>>>>>> 94335cf5ca7bbc72afd94673535ee2de1b814e07
>>>>>>> ce3721426dc0e807cf93d0f218bb797df5a9b9ce
simple_neural_network.print_statistics()

# normal check
#lower_bound2 = lower_bound
#upper_bound2 = upper_bound

# adversarial check
lower_bound2 = -100.0
upper_bound2 =  100.0

<<<<<<< HEAD
simple_neural_network.plot_model(10000,lower_bound2,upper_bound2)
=======
#simple_neural_network.plot_model(10000,lower_bound2,upper_bound2)
>>>>>>> 94335cf5ca7bbc72afd94673535ee2de1b814e07





