# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 15:25:41 2019

@author: Gerry Dozier
"""
import os
import random
import sys
import math
import time
import numpy as np
import sklearn
from random import sample
from sklearn.svm import SVC
from sklearn.datasets import load_iris
from sklearn import random_projection
from sklearn import svm
from sklearn import datasets
from sklearn import random_projection
from sklearn.model_selection import train_test_split
#split data set into train and test sets

import matplotlib.pyplot as plt
#import csv
#import numpy as np
from mpl_toolkits.mplot3d import Axes3D


class aGaussianKernel:
    def __init__(self, target, desired_output):
        self.target = target
        self.desired_output = desired_output     

    def fire_strength(self, q, sigma):
        sum_squared = 0.0
        for i in range(0,len(q)):
            sum_squared += math.pow((q[i] - self.target[i]),2.0)
        #print("FS Sum_Squared = " + str(sum_squared))
        return math.exp(-sum_squared/(2.0*pow(sigma,2.0)))
        
    def print_gaussian_kernel(self):
        print("Target = ", self.target, " Desired Output = " + str(self.desired_output))
    
         

class RBF():#StationaryKernelMixin, NormalizedKernelMixin, Kernel):
    """Radial-basis function kernel (aka squared-exponential kernel).
    The RBF kernel is a stationary kernel. It is also known as the
    "squared exponential" kernel. It is parameterized by a length-scale
    parameter length_scale>0, which can either be a scalar (isotropic variant
    of the kernel) or a vector with the same number of dimensions as the inputs
    X (anisotropic variant of the kernel). The kernel is given by:
    k(x_i, x_j) = exp(-1 / 2 d(x_i / length_scale, x_j / length_scale)^2)
    This kernel is infinitely differentiable, which implies that GPs with this
    kernel as covariance function have mean square derivatives of all orders,
    and are thus very smooth.
    .. versionadded:: 0.18
    Parameters
    ----------
    length_scale : float or array with shape (n_features,), default: 1.0
        The length scale of the kernel. If a float, an isotropic kernel is
        used. If an array, an anisotropic kernel is used where each dimension
        of l defines the length-scale of the respective feature dimension.
    length_scale_bounds : pair of floats >= 0, default: (1e-5, 1e5)
        The lower and upper bound on length_scale
    """
    def __init__(self):#, length_scale=1.0, length_scale_bounds=(1e-5, 1e5)):
        self.length_scale = 1#length_scale
        self.length_scale_bounds = 1#length_scale_bounds

    #@property
    def anisotropic(self):
        return np.iterable(self.length_scale) and len(self.length_scale) > 1

    #@property
    def hyperparameter_length_scale(self):
        if self.anisotropic:
            return Hyperparameter("length_scale", "numeric",self.length_scale_bounds,len(self.length_scale))
        else:
            return Hyperparameter("length_scale", "numeric", self.length_scale_bounds)

    def __call__(self):#, X, Y=None, eval_gradient=False):
        """Return the kernel k(X, Y) and optionally its gradient.
        Parameters
        ----------
        X : array, shape (n_samples_X, n_features)
            Left argument of the returned kernel k(X, Y)
        Y : array, shape (n_samples_Y, n_features), (optional, default=None)
            Right argument of the returned kernel k(X, Y). If None, k(X, X)
            if evaluated instead.
        eval_gradient : bool (optional, default=False)
            Determines whether the gradient with respect to the kernel
            hyperparameter is determined. Only supported when Y is None.
        Returns
        -------
        K : array, shape (n_samples_X, n_samples_Y)
            Kernel k(X, Y)
        K_gradient : array (opt.), shape (n_samples_X, n_samples_X, n_dims)
            The gradient of the kernel k(X, X) with respect to the
            hyperparameter of the kernel. Only returned when eval_gradient
            is True.
        """
        X = 1#np.atleast_2d(X)
        length_scale = _check_length_scale(X, self.length_scale)
        if Y is None:
            dists = 1#pdist(X / length_scale, metric='sqeuclidean')
            K = 1#np.exp(-.5 * dists)
            # convert from upper-triangular matrix to square matrix
            K = 1#squareform(K)
            np.fill_diagonal(K, 1)
        else:
            if eval_gradient:
                raise ValueError("Gradient can only be evaluated when Y is None.")
            dists = 1#cdist(X / length_scale, Y / length_scale,metric='sqeuclidean')
            K = 1#np.exp(-.5 * dists)

        if eval_gradient:
            if self.hyperparameter_length_scale.fixed:
                # Hyperparameter l kept fixed
                return 1#K, np.empty((X.shape[0], X.shape[0], 0))
            elif not self.anisotropic or length_scale.shape[0] == 1:
                K_gradient = 1#(K * squareform(dists))[:, :, np.newaxis]
                return 1#K, K_gradient
            elif self.anisotropic:
                # We need to recompute the pairwise dimension-wise distances
                K_gradient = 1#(X[:, np.newaxis, :] - X[np.newaxis, :, :]) ** 2 / (length_scale ** 2)
                K_gradient *= 1#K[..., np.newaxis]
                return 1#K, K_gradient
        else:
            return 1#K

#    def __repr__(self):
#        if self.anisotropic:
#            return 1#"{0}(length_scale=[{1}])".format(self.__class__.__name__, ", ".join(map("{0:.3g}".format,self.length_scale)))
#        else:  # isotropic
#            return 1#"{0}(length_scale={1:.3g})".format(self.__class__.__name__, np.ravel(self.length_scale)[0])
    def output():
        if X > 0.5:
            return output = 1
        else:
            return output = -1
        
rbf_example = RBF()
rbf_example.length_scale
rbf_example.length_scale_bounds
rbf_example.hyperparameter_length_scale()
rbf_example.anisotropic()
        
class aSimpleNeuralNetwork:
    def __init__(self,dataset_file_name,num_of_inputs,num_of_outputs):
        self.dataset_file_name = dataset_file_name
        self.num_of_inputs = num_of_inputs
        self.num_of_outputs = num_of_outputs
        self.training_instance = []
        self.data = []
        self.neuron = []
        self.sigma = 0
        self.tp = 0         # true positive
        self.tn = 0         # true negative
        self.fp = 0         # false positive
        self.fn = 0         # false negative
        
        
        with open(self.dataset_file_name, "r") as dataset_file:
            for line in dataset_file:
                line = line.strip().split(" ")
                self.data.append([float(x) for x in line[0:]])
                
        for i in range(len(self.data)):
            temp = aGaussianKernel(self.data[i][:self.num_of_inputs],self.data[i][self.num_of_inputs])
            self.neuron.append(temp)
         
            
        self.train_data, self.validate, self.test = np.split(self.data, [int(.8*len(self.data)), int(.9*len(self.data))])
        
#        self.data_out_forward = forward_pass(self)
#        self.data_out_backward = backward_pass(self)
#        self.data_out_EBP = error_backpropagation(self)

    def sigmoid(net):
        out = 1/(1+np.exp(-net))
        return out
#        
#    def net_sum(w,x):
#        net = w*x
#        return net
#        
##    def del_w_component(net,w):
##        del_w = net/w#del_net/del_w
##        return del_w
#    
#    def forward_pass():#self):
#        #Forward Pass
#        for i in range(0,1,1):#len(self.data)):
#            net = 1
#            #net[i] = net_sum(w[i],x[i])
#            o = 1
#            #o[i] = sigmoid(net[i])
#        
#    def backward_pass():#self):
#        #Backward Pass
#        for i in range(0,1,1):#len(self.data)):
#            w[i] = 1
#            #w = 1
#        
#    def error_backpropagation():#self):
#        #Error Back-Propagation
#        for i in range(0,1,1):#len(self.data),1):
#            error_w[i] = 1
#        
#        
##        self.data_train, self.data_test, self.target_train, self.target_test = train_test_split(self.data, self.target, test_size = 0.1, random_state = 1)
##        self.data_train, self.data_val, self.target_train, self.target_val = train_test_split(data_train, target_train, test_size = 0.1, random_state = 1)
#        
#        
#        
#    def kohonen_clustering():
#        for i in range(0,1,1):#len(self.data),1):
#            clusters[i] = 1
#            kohonen_weights[i] = 1
#        return clusters
        
    def RBFNN():
#        i = 1
#        j = 1
#        x[i] = 1
#        x[j] = 1
#        d = 1
#        n = x[i]
#        m = x[j]
#        RBFNN_kernel[n][m] = np.exp(-1/(2*d*((x[i]/l,x[j]/l))))
#        RBFNN_outputs = 1 
#        #for i in range(0,len(data),1)
#            #z_input = z[p]
#            #u_mean = u[j]
#            #linear_function = (z_input-u_mean)**2
#            #gaussian_function = np.exp(-(((z_input-u_mean))**2)/(2*(sigma**2)))
#            #RBFNN_outputs += w[i]*y[i]
#        for j in range(0,1,1):
#            sigma[j] = d_max/np.sqrt(J)
#            w[k] = np.inv(np.transpose(phi)*phi)*np.transpose(phi)*t[k]
        
#        data = dg 
        learningrate = 0.1
        w0 = 1
        w1 = 1
        w2 = 1
        for i in range(0.len(data),1):
            in1 = data[i][0]
            in2 = data[i][1]
            bias = -1.0
            in0 = bias
            out = data[i][2]
            neuron_H = (w1*in1) + (w2*in2) + (w0*bias)
            if neuron_H > 0.5:
                neuron_out = 1.0
            else: 
                neuron_out = -1.0
            x = in1
            y = in2
            o = neuron_out
            out0 = o - ((w1*in1) + (w2*in2))#input to H, estimated based on the output
            out1 = o - ((w0*bias) + (w2*in2))#input to H, estimated based on the output
            out2 = o - ((w1*in1) + (w0*bias))#input to H, estimated based on the output
            e0 = bias - out0
            e1 = in1 - out1#bias*out1
            e2 = in2 - out2#bias*out2
            delta_w0 = w0 - e0/bias
            delta_w1 = w1 - e1/in1
            delta_w2 = w2 - e2/in2
            w0 = w0 - learningrate*delta_w0
            w1 = w1 - learningrate*delta_w1
            w2 = w2 - learningrate*delta_w2
            
#            e2 = 
#            data_out = 
        return RBFNN_outputs
    
        
    #The accuracy of the RBFNN is influenced by the number of basis functions used, the location of the basis functions, and the width of the receptive field. Training a RBFNN can be don using algorithms that adapt only the weights between the hidden and output layers, algorithms that adapt both weights, centers, and deviations, or other algorithms. 
    #A training algorithm that utilizes Kohonen unsupervised learning to develop the clustering can be used \cite{Engelbrecht}.%pg. 79
    #The K-means algorithm can be used . 
    #
        
    def set_sigma(self, sigma):
        self.sigma = sigma
        
    def distance_squared(self,x,y):
        dist_sqrd = 0
        for i in range(len(x)):
            dist_sqrd += (x[i] - y[i])**2
        return dist_sqrd    
    
    def train(self):
        dmax = 0
        dist_squared = 0
        for i in range(len(self.train_data)-1):
            for j in range((i+1),len(self.train_data)):
                dist_squared = self.distance_squared(self.neuron[i].target,self.neuron[j].target)
                if dmax < dist_squared:
                    dmax = dist_squared
        self.sigma = math.sqrt(dmax)
        print("dmax =", self.sigma)
        print("total training data: ", len(self.train_data))
        
    
    
    def check(self,query):
        sum_fire_strength = 0
        sum_fire_strength_x_desired_output = 0
        for i in range(len(self.neuron)):
            the_fire_strength = self.neuron[i].fire_strength(query,self.sigma)
            sum_fire_strength_x_desired_output += the_fire_strength * self.neuron[i].desired_output
            sum_fire_strength += the_fire_strength
        if (sum_fire_strength == 0.0):
            sum_fire_strength = 0.000000001               # to prevent divide by zero
        return sum_fire_strength_x_desired_output/sum_fire_strength
    
    def test_model(self,number_of_test_cases):
        for i in range(number_of_test_cases):
            test_case = []
            sum_squared_error = 0
            x = random.uniform(-100.0,100.0)
            y = random.uniform(-100.0,100.0)
            test_case.append(x)
            test_case.append(y)
            
            x2y2 = x**2 + y**2
            SchafferF6 = 0.5 + (math.sin(math.sqrt(x2y2))**2 - 0.5) / (1+0.001*x2y2)**2
            
            test_instance_result = self.check(test_case)
            sum_squared_error += (test_instance_result - SchafferF6)**2
            self.calculate_statistics(test_instance_result,SchafferF6)
        return (sum_squared_error/number_of_test_cases)
    
    
    def calculate_statistics(self, test_instance_result, SchafferF6):
       # print("in calculate", test_instance_result, " ", SchafferF6)
        if ((test_instance_result > 0.5) and (SchafferF6 > 0.5)):
            self.tp += 1
        if ((test_instance_result <= 0.5) and (SchafferF6 <= 0.5)):
            self.tn += 1
        if ((test_instance_result > 0.5) and (SchafferF6 <= 0.5)):
            self.fp += 1
        if ((test_instance_result <= 0.5) and (SchafferF6 > 0.5)):
            self.fn += 1
           
    def plot_model(self, number_of_test_cases, lb, ub):
        test_case_x = []
        test_case_y = []
        test_case_z = []
        
        schafferF6_x = []
        schafferF6_y = []
        schafferF6_z = []
        
        for i in range(number_of_test_cases):
            x = random.uniform(lb,ub)
            y = random.uniform(lb,ub)
            
            test_case_x.append(x)
            test_case_y.append(y)
            schafferF6_x.append(x)
            schafferF6_y.append(y)
            
            test_case = []
            test_case.append(x)
            test_case.append(y)
            #print("test case: ",test_case)
            test_case_z.append(self.check(test_case))
            
            x2y2 = x**2 + y**2
            SchafferF6 = 0.5 + (math.sin(math.sqrt(x2y2))**2 - 0.5) / (1+0.001*x2y2)**2
            schafferF6_z.append(SchafferF6)
            
        fig = plt.figure()
        ax1 = fig.add_subplot(1,1,1,projection='3d')
        ax1.scatter(test_case_x,test_case_y,test_case_z,edgecolor='white')#,cmap='plasma',edgecolor='white')
        plt.title("Simple Neural Network")
        ax1.set_zlim3d(0.2,1.0)
        plt.show()
        
        fig = plt.figure()
        ax2 = fig.add_subplot(1,1,1,projection='3d')
        ax2.scatter(schafferF6_x,schafferF6_y,schafferF6_z,edgecolor='white')#,edgecolors=colors)#cmap='ocean')#,edgecolor='white')
        plt.title("SchafferF6")
        ax2.set_zlim3d(0.2,1.0)
        plt.show()
            
    def print_training_set(self):
        print(self.train_data)
        print(len(self.train_data))
    
    def print_neurons(self):
        for i in range(len(self.neuron)):
            self.neuron[i].print_gaussian_kernel()

    def print_statistics(self):
        accuracy = (self.tp + self.tn)/(self.tp + self.tn + self.fp + self.fn)
        recall   = self.tp/(self.tp + self.fn + 0.00001)
        precision = self.tp/(self.tp + self.fp + 0.00001)
        f1        = 2*(precision * recall)/(precision + recall + 0.00001)
        print("Accuracy:  ", accuracy)
        print("Recall:    ", recall)
        print("Precision: ", precision)
        print("F1:        ", f1)

class dataset_generator:
    def __init__(self,filename,lb,ub):
        self.filename = filename
        self.lb = lb
        self.ub = ub
    
    def generate_dataset(self,number_of_training_instances):
        dataset_file = open(self.filename, 'w')
        for i in range (number_of_training_instances):
            x = random.uniform(self.lb,self.ub)
            y = random.uniform(self.lb,self.ub)
            x2y2 = x**2 + y**2
            dataset_file.write(str(x) + " " + str(y) + " " + str(0.5 + (math.sin(math.sqrt(x2y2))**2 - 0.5) / (1+0.001*x2y2)**2) + "\n")
        dataset_file.close()

lower_bound = -100.0
upper_bound =  100.0

dg = dataset_generator('Project3_Dataset_v2.txt',lower_bound,upper_bound)
dg.generate_dataset(1000)

#simple_neural_network = aSimpleNeuralNetwork('C:\\Users\\alj0032\\gitlab\\project3\\Project3_Dataset_v1.txt',2,1)
simple_neural_network = aSimpleNeuralNetwork('Project3_Dataset_v1.txt',2,1)
#simple_neural_network = aSimpleNeuralNetwork('C:\Users\alj0032\gitlab\project3\Project3_Dataset_v1.txt',2,1)

#data_out_forward = simple_neural_network.forward_pass()
#data_out_backward = simple_neural_network.backward_pass()
#data_out_EBP = simple_neural_network.error_backpropagation()

simple_neural_network.forward_pass()#simple_neural_network.data)
simple_neural_network.backward_pass()#simple_neural_network.data)
simple_neural_network.error_backpropagation()#simple_neural_network.data)

simple_neural_network.train()
simple_neural_network.set_sigma(10)

simple_neural_network.distance_squared()
simple_neural_network.test_model()
data = dg
simple_neural_network.RBF()

print("Model Test AMSE: ", simple_neural_network.test_model(len(simple_neural_network.test)))
simple_neural_network.print_statistics()

# normal check
#lower_bound2 = lower_bound
#upper_bound2 = upper_bound

# adversarial check
lower_bound2 = -100.0
upper_bound2 =  100.0

simple_neural_network.plot_model(10000,lower_bound2,upper_bound2)


'''



% --------------------------------------------------
% --------------------------------------------------



% -----------------------------------------------------
% -----------------------------------------------------
% INTRODUCTION/SUMMARY --------------------------------
%Kohonen Introduction/Summary
\subsection{Kohonen}
\subsubsection{Learning Vector Quantizer - I}
The clustering algorithm constructs clusters of similar input vectors (patterns), where  similarity is usually measured in terms of Euclidean distance\cite{Engelbrecht}. %pg. 60
The training process of Learning Vector Quantizer - I (LVQ-I) is based on competition. 
During training, the cluster unit whose weight vector is the "closest" to the current input pattern is declared as the winner. The corresponding weight vector and that of the neighboring units are then adjusted to better resemble the input pattern\cite{Engelbrecht}. 
It is not strictly necessary that LVQ-I uses a neighborhood function, thereby updating only the weights of the winning output unit\cite{Engelbrecht}. 

\subsubsection{Learning Vector Quantizer - II}
The Kohonen Learning Vector Quantizer - II (LVQ-II) uses information from a supervisor to implement a reward and punish scheme. LVQ-II assumes that the classifications of all input patterns are known. If the winning cluster unit correctly classifies the pattern, then the weights to that unit are rewarded by moving the weights to better match the input pattern. However, if the winning unit misclassified the input pattern, the weights are penalized by moving the weights away from the input vector\cite{Engelbrecht}. %pg. 73 
Similarly to LVQ-I, a conscience factor can be incorporated to penalize frequent winners.

%RBFNN Introduction/Summary
\subsection{Radial Basis Function Neural Network}
A radial basis function (RBF) neural network (RBFNN) is a FFNN where hidden units do not implement an activation function, but represents a radial basis function. A RBFNN approximates a desired function by superposition of nonorthogonal, radially symmetric functions\cite{Engelbrecht}. %pg. 73-74
RBFNNs can improve accuracy and decrease training time complexity. The architecture of a RBFNN is similar to that of a FFNN, with the differences being that the hidden units implement a radial basis function, weights from the input units to the a hidden unit represent the center of the radial basis function, and some radial basis functions are characterized by a width, \begin{math}\sigma\end{math}. For such basis functions, the weight from the basis unit in the input layer to each hidden unit represents the width of the basis function. Note that the input unit has an input signal of \begin{math}+1\end{math}\cite{Engelbrecht}. %pg. 75
The output units of a RBFNN implement linear activation functions, so the output is simply a linear combination of basis functions. 
As with FFNNs, RBFNNs are universal approximators\cite{Engelbrecht}. %pg. 75

A limitation of K-Nearest Neighbors is that a large database of training examples must be kept in order to predictions. The LVQ-I algorithm allows learning with a much smaller subset of patterns that best represent the training data. 



%Back-Propagation Introduction/Summary
\subsection{Back-Propagation}







% -----------------------------------------------------
% -----------------------------------------------------
% METHODOLOGY -----------------------------------------
%Kohonen Methodology
\subsection{Kohonen}
First, the network weights, the learning rate, and the neighborhood radius are initialized. The Kohonen LVQ-I algorithm initializes the weights with random values, samples from a uniform distribution, or by taking the first input patterns as the initial weight vectors. Stopping conditions may be: a maximum number of epochs is reached, stop when weight adjustments are sufficiently small, or a small enough quantization error has been reached. While the stopping conditions are not true, for each pattern, the Euclidean distance is calculated. The output unit for which the distance is the smallest is found. Then, all the weights are updated for the neighborhood. After each pattern has had all of the weights updated, the learning rate is updated. Then, the neighborhood radius is reduced at specified learning iterations. 

%RBFNN Methodology
\subsection{Radial Basis Function Neural Network}
Each hidden unit implements a radial basis function, or kernel function, which is a strictly positive, radially symmetric function. A Radial Basis Function (RBF) has a unique maximum at its center, \begin{math}\mu\end{math}, and the function usually drops off to zero rapidly further away from the center. The output of a hidden unit indicates the closeness of the input vector, \begin{math}z_p\end{math}, to the center of the basis function. Some RBFs are characterized by a width, \begin{math}\sigma_j\end{math}, which specifies the width of the receptive field of the RBF in the input space for the hidden unit \begin{math}j\end{math}. 

A Linear RBF is shown in Equation (\ref{eq_linearRBF}). 

\begin{equation}
\begin{Equation~\ref{}}
{\Phi}({{||}{z_p}-(\mu_j}{{||}_2}}) = {{||}{z_p}-(\mu_j}{{||}_2}}
\label{eq_linearRBF}
\end{Equation~\ref{}}

\subsubsubsection{Algorithms for Training RBFNNs}
Methods used to train RBFNNs differe in the number of parameters that are learned. The fixed centers algorithm adapts only the weights between the hidden and output layers. Adaptive centers training algorithms adapt weights, centers, and deviations. Gradient descent can be used to adjust weights, centers, and widths. Centers can be initialized in an unsupervised training step, prior to training the weights between hidden units (radial basis) and output units\cite{Engelbrecht}. %pg. 77




% To reach a desired accuracy, \begin{math}{MSE}_s\end{math}, on the unscaled data set, the Neural Network must be trained longer until \begin{math}{{MSE}_s}=({{c_1}^2}){{MSE}_r}\end{math}\cite{Engelbrecht}. %pg. 103

% For some Neural Network types, such as the LVQ, input data is preferred to be normalized to vectors of unit length. The normalization above loses information on the absolute magnitude of the input parameters, since it requires the length of all input vectors (patterns) to be the same\cite{Engelbrecht}. %pg. 104

\subsubsection{Weight Initialization}
Gradient-based optimization methods, such as gradient descent, are very sensitive to the initial weight vectors. If the initial position is near the local minimum, then convergence will be quick. However, if the initial weight vector is on a flat area on the error surface, then convergence is slow. Also, large initial weight values may prematurely saturate units due to extreme output values with associated zero derivatives. In the case of optimization algorithms, such as Particle Swarm Optimization (PSO) and Genetic Algorithms (GAs), initialization should be uniformly distributed over the entire search space to ensure that all parts of the search space are coveredcite{Engelbrecht}. %pg. 106


\subsubsection{Momentum}
Stochastic learning, where weights are adjusted after each pattern presentation, has the disadvantage of fluctuating changes in the sign of the error derivatives. The network spends a lot of time going back and forth, unlearning what the previous steps have learned. Batch learning is a solution to this problem, since weight changes are accumulated and applied only after all patterns in the training set have been presented. Another solution is to keep with stochastic learning, and to add a momentum term\cite{Engelbrecht}. %pg. 108
The idea of the momentum term is to average the weight changes, thereby ensuring that the search path is in the average downhill direction. The momentum term is then simply the previous weight change weighted by a scalar value \begin{math}\alpha\end{math}\cite{Engelbrecht}. %pg. 109 



%Back-Propagation Methodology
\subsection{Back-Propagation}



% -----------------------------------------------------
% -----------------------------------------------------
% EXPERIMENT ------------------------------------------
%Kohonen Experiment
\subsection{Kohonen}

%RBFNN Experiment
\subsection{Radial Basis Function Neural Network}
Gradient Descent Training of RBFNNs begins with the selection of the number of centers. For each center, the center location, mean, and \begin{math}\sigma_j\end{math} values are chosen. Then, each weight is initialized. Next, a loop that runs until a stopping condition is reached computes the output, weight adjustment step size, and adjusts the weights. Lastly, the center step size is also computed, and the centers are adjusted. The \begin{math}\sigma_j\end{math} width step size is computed, and then the widths are adjusted. 
\cite{Engelbrecht}. %pg. 78

Before the LVQ-I training phase, the RBFNN is initialized. The centers are initialized by setting all the \begin{math}\mu_{ji}\end{math} weights to the average value of all inputs in the training set. The weights are initialized by setting all \begin{math}\sigma_j\end{math} to the standard deviation of all input values of the training set. The hidden-to-output weights, \begin{math}w_{ki}\end{math}, are initialized to small random values. At the end of each LVQ-I iteration, the basis function widths are recalculated. For each hidden unit, the average of the Euclidean distance between \begin{math}\mu_{ji}\end{math} and the input patterns for which the hidden unit was selected as the winner. The width, \begin{math}\sigma_j\end{math}, is set to the average\cite{Engelbrecht}. %pg. 79


%Back-Propagation Experiment
\subsection{Back-Propagation}
The training set provides data for the neural network to be trained on, and the bias value represents the threshold values of neurons in the next layer\cite{Engelbrecht}. %pg. 29 
To simplify learning equations, the input vector is augmented to include and additional input unit, or the bias unit. The weight of the bias unit serves as the value of the threshold\cite{Engelbrecht}. %pg. 24 
The strength of the output signal is influenced by the threshold value, or bias\cite{Engelbrecht}. %pg. 17







% -----------------------------------------------------
% -----------------------------------------------------
% RESULTS ---------------------------------------------
%Kohonen Results
\subsection{Kohonen}
A problem with LVQ networks is that one cluster unit may dominate as the winning cluster unit, thus putting most patterns in one cluster. To prevent one output unit from dominating, a "conscience" factor that penalizes an output for winning too many times may be incorporated in a function to determine the winning output unit\cite{Engelbrecht}. 

% The  more an output unit wins, the larger the value of .... becomes, and .... becomes more negative. 

%RBFNN Results
\subsection{Radial Basis Function Neural Network}
The accuracy of a RBFNN is influeced by: the number of basis functions used, the location of the basis functions, and the width of the receptive field, \begin{math}\sigma_j\end{math}. A larger \begin{math}\sigma_j\end{math} represents more of the input space by that basis function. The larger the number of basis functions that are used, the better the approximation of the target function. However, the cost is an increase in computational complexity. The location of the basis fuctions are defined by the center vector, \begin{math}\eta_j\end{math}, for each basis function. Basis functions should be evenly distributed to cover the entire input space\cite{Engelbrecht}. %pg. 76

Training of a RBFNN should consider methods to find the best values for the parameters that affect the accuracy of the RBFNN. 


%Back-Propagation Results
\subsection{Back-Propagation}
For the RBFNN without Kohonen Unsupervised Learning and Backpropagation, the accuracy is 0.2, while the precision is 0.2. The recall is 0.2, while the F1 value is 0.2. 

For the RBFNN with Kohonen Unsupervised Learning and Backpropagation, the accuracy is 0.4, while the precision is 0.4. The recall is 0.4, while the F1 value is 0.4. 


% -----------------------------------------------------
% -----------------------------------------------------
% CONCLUSION ------------------------------------------
%Kohonen Conclusion
\subsection{Kohonen}

%RBFNN Conclusion
\subsection{Radial Basis Function Neural Network}


%Back-Propagation Conclusion
\subsection{Back-Propagation}








% --------------------------------------------------
% --------------------------------------------------









%THESIS: 
Information matrix pruning techniques: Several researchers have used approximations to the Fisher information matrix to determine the optimal number of hidden units and weights. Based on the assumption that outputs are linearly activated, and that least squares estimators satisfy asymptotic normality, previous research computes the relevance of a weight as a function of the information matrix, which can be approximated. Weights with a low relevance are removed\cite{Engelbrecht}. %pg. 113



Sensitivity analysis pruning techniques: Two main approaches to sensitivity analysis exist, namely with regard to the objective function and with regard to the NN output function. Both sensitivity analysis with regard to the objective function and sensitivity analysis with regard to the NN output function resulted in the development of a number of pruning techniques. Possibly the most popular of these are optimal brain damage (OBD) [166] and its variants, optimal brain surgeon (OBS) [351, 352] and optimal cell damage (OCD) [129]. A parameter saliency measure is computed for each parameter, indicating the influence small perturbations to the parameter have on the approximation error. Parameters with a low saliency are removed. These methods are time-consuming due to the calculation of the Hessian matrix. Buntine and Weigend [95] and Bishop [71] derived methods to simplify the calculation of the Hessian matrix in a bid to reduce the complexity of these pruning techniques. In OBD, OBS and OCD, sensitivity analysis is performed with regard to the training error. Pedersen et al. [669] and Burrascano [98] develop pruning techniques based on sensitivity analysis with regard to the generalization error. Other objective function sensitivity analysis pruning techniques have been developed by Mozer and Smolensky [611] and Moody and Utans [602]\cite{Engelbrecht}. %pg. 115

NN output sensitivity analysis pruning techniques have been developed that are less complex than objective function sensitivity analysis, and that do not rely on simplifying assumptions. Zurada et al. [962] introduced output sensitivity analysis pruning of input units, further investigated by Engelbrecht et al. [245]. Engelbrecht and Cloete [238, 240, 246] extended this approach to also prune irrelevant hidden units\cite{Engelbrecht}. %pg. 115

A similar approach to NN output sensitivity analysis was followed by Dorizzi et al. [218] and Czernichow [168] to prune parameters of a RBFNN\cite{Engelbrecht}. %pg. 115

The aim of all architecture selection algorithms is to find the smallest architecture that accurately fits the underlying function\cite{Engelbrecht}. %pg. 115





'''


