# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 15:25:41 2019

@author: Gerry Dozier
"""
import os
import random
import sys
import math
import time
import numpy as np
import sklearn
from random import sample
from sklearn.svm import SVC
from sklearn.datasets import load_iris
from sklearn import random_projection
from sklearn import svm
from sklearn import datasets
from sklearn import random_projection
from sklearn.model_selection import train_test_split
#split data set into train and test sets

import matplotlib.pyplot as plt
#import csv
#import numpy as np
from mpl_toolkits.mplot3d import Axes3D

# Learning Vector Quantizer - 1 (LVQ-I)
# [Engelbrecht, pg. 59-61]
# Unsupervised Version of the LVQ-I
'''



'''
class kohonen():
    def clusters():
        for k in range(0,len(data),1):
            o[k] = 1
        return o
    def weight_update(): 
        # Initialize the network weights, the learning rate, and the neighborhood radius
        # while stopping condition(s) not true, do
        #   for each pattern p do
        #       Compute the Euclidean distance, d[k][p], between input vector z[p] and each weight vector u[k] = [u[k][0],u[k][1],u[k][2],u[k][3]] as d[k][p] = #Euclidean Distance Equation
        #       Find the output unit o[k]
        #       Update all the weights for the neighborhood kk[k][p] using the delta_u[k][i] equation
        #   Update the learning rate
        #   Reduce the neighborhood radius at specified learning iterations
        #Weights are: 
        # - initialized to random values
        # - sampled from a uniform distribution
        # - initialized by taking the first input patterns as the initial weight vectors
        u[1][1] = z[1][1]
        u[1][2] = z[1][2]
        u[2][1] = z[2][1]
        u[2][2] = z[2][2]
        
        #Stopping conditions may be: 
        # - a maximum number of epochs (time instances) is reached
        # - stop when weight adjustments are sufficiently small
        # - a small enough quantization error has been reached, where the quantization error is defined as 
        Q_T = np.sum((z[p] - u[k])^2)/P_T
        
        mu = 1  #fix this #a decaying learning rate
        u_previous = data  #fix this
        for i in range (0,len(data),1):
            for k in range(0,len(data),1):
                p = i #fix this #pattern
                kk = 1 #fix this #the set of neighbors of the winning cluster unit o[k] for pattern p
                z1 = 1
                z2 = 1
                o1 = 1
                z = [z1 z2] #the input space
                o = [o1] #the output space
                diff_z_u = z[i][p] - u_previous[k][i]
                if k == kk[k][p]:
                    delta_u[k][i] = mu*diff_z_u
                else:
                    delta_u[k][i] = 0
#                for i in range(0,len(data),1):
#                    for p in range(0,len(data),1):
#                        for k in range(0,len(data),1):
#                            d[k][p] = np.sum((z[i][p] - u_previous[k][i])^2) #np.sum((z[i][p] - u_previous[k][i])^2) #z[i][p] - u_previous[k][i] #diff_z_u #Euclidean distance
                #Usually, for normalized inputs, beta = 0.0001 and gamma = 10. 
                beta =  0.0001
                gamma =  10
                d[k][p] = np.sum((z[i][p] - u_previous[k][i])^2) #np.sum((z[i][p] - u_previous[k][i])^2) #z[i][p] - u_previous[k][i] #diff_z_u #Euclidean distance
                error[k][p] = np.sqrt(np.sum((z[i][p] - u_previous[k][i])^2)) #Square root of the sum of the squared differences between the two vectors
                g[k] = g_previous[k] + beta*(o[k][p] - g_previous[k]) #g[k] = 0 #initialized to 0
                Ii = np.eye(len(g)) #the total number of input units 
                b[k] = gamma*((1/Ii)- g[k]) #initialized to 1/Ii #the conscience factor defined for each output unit 
                if np.min() == d[k][p] - b[k]:
                    o[k][p] = 1
                else: 
                    o[k][p] = 0
        return delta_u
    
    def lvqII(): 
        

#class UnsupervisedLearningNeuralNetwork():

# Stochastic Training Rule
# [Engelbrecht, pg. 62-65]
class SOM(): #Self-Organizing Map is based on a competitive learning strategy. 
    neurons = 1 #number of elements (neurons) in the map
    training_patterns = 1 #number of training patterns
#    training_patterns <= neurons
#    neurons = training_patterns #ideal
    
    # - - - - 
    #Assign randomly selected input patterns. 
    p = np.random.uniform(1,P_T)
    for k in range(0,len(data),1): 
        for j in range(0,len(data),1): 
            w[k][j] = z[p]
    #This approach may lead to premature convergence
    # - - - - 
    
    # - - - - 
    # Weights of boundary neurons are initialized as
    J = 1#len(data)
    K = 1#len(data)
#    for K in range(0,len(data),1):
    for j in range(2,J-1,1):
#        for J in range(0,len(data),1):
        for k in range(2,K-1,1):
        w[1][j] = ((w[1][J]-w[1][1])/(J-1))*(j-1) + w[1][1]
        w[K][j] = ((w[K][J]-w[K][1])/(J-1))*(j-1) + w[K][1]
        w[k][1] = ((w[K][1]-w[1][1])/(K-1))*(k-1) + w[1][1]
        w[k][J] = ((w[K][J]-w[1][J])/(K-1))*(k-1) + w[1][J]
    # The remaining codebook vectors are initialized as
    J = 1#len(data)
    K = 1#len(data)
#    for K in range(0,len(data),1):
    for j in range(2,J-1,1):
#        for J in range(0,len(data),1):
        for k in range(2,K-1,1):
        w[k][j] = ((w[k][J]-w[k][1])/(J-1))*(j-1) + w[k][1]
    # - - - - 
    
    # - - - - 
    # For each neuron, the associated codebook vector is updated as
    J = 1#len(data)
    K = 1#len(data)
#    for K in range(0,len(data),1):
    for j in range(2,J-1,1):
#        for J in range(0,len(data),1):
        for k in range(2,K-1,1):
        w[k][j] = w[k][j] + h[m][n]*(z[p] - w[k][j])#((w[k][J]-w[k][1])/(J-1))*(j-1) + w[k][1]
    
    
    # - - - - 
    
            
    
    
    
    
    
    
    
    

class RBF():#StationaryKernelMixin, NormalizedKernelMixin, Kernel):
    """Radial-basis function kernel (aka squared-exponential kernel).
    The RBF kernel is a stationary kernel. It is also known as the
    "squared exponential" kernel. It is parameterized by a length-scale
    parameter length_scale>0, which can either be a scalar (isotropic variant
    of the kernel) or a vector with the same number of dimensions as the inputs
    X (anisotropic variant of the kernel). The kernel is given by:
    k(x_i, x_j) = exp(-1 / 2 d(x_i / length_scale, x_j / length_scale)^2)
    This kernel is infinitely differentiable, which implies that GPs with this
    kernel as covariance function have mean square derivatives of all orders,
    and are thus very smooth.
    .. versionadded:: 0.18
    Parameters
    ----------
    length_scale : float or array with shape (n_features,), default: 1.0
        The length scale of the kernel. If a float, an isotropic kernel is
        used. If an array, an anisotropic kernel is used where each dimension
        of l defines the length-scale of the respective feature dimension.
    length_scale_bounds : pair of floats >= 0, default: (1e-5, 1e5)
        The lower and upper bound on length_scale
    """
    def __init__(self, length_scale=1.0, length_scale_bounds=(1e-5, 1e5)):
        self.length_scale = length_scale
        self.length_scale_bounds = length_scale_bounds

    #@property
    def anisotropic(self):
        return np.iterable(self.length_scale) and len(self.length_scale) > 1

    #@property
    def hyperparameter_length_scale(self):
        if self.anisotropic:
            return 1#Hyperparameter("length_scale", "numeric",self.length_scale_bounds,len(self.length_scale))
        else:
            return 1#Hyperparameter("length_scale", "numeric", self.length_scale_bounds)

    def __call__(self):#, X, Y=None, eval_gradient=False):
        """Return the kernel k(X, Y) and optionally its gradient.
        Parameters
        ----------
        X : array, shape (n_samples_X, n_features)
            Left argument of the returned kernel k(X, Y)
        Y : array, shape (n_samples_Y, n_features), (optional, default=None)
            Right argument of the returned kernel k(X, Y). If None, k(X, X)
            if evaluated instead.
        eval_gradient : bool (optional, default=False)
            Determines whether the gradient with respect to the kernel
            hyperparameter is determined. Only supported when Y is None.
        Returns
        -------
        K : array, shape (n_samples_X, n_samples_Y)
            Kernel k(X, Y)
        K_gradient : array (opt.), shape (n_samples_X, n_samples_X, n_dims)
            The gradient of the kernel k(X, X) with respect to the
            hyperparameter of the kernel. Only returned when eval_gradient
            is True.
        """
        X = np.atleast_2d(X)
        length_scale = _check_length_scale(X, self.length_scale)
        if Y is None:
            dists = pdist(X / length_scale, metric='sqeuclidean')
            K = np.exp(-.5 * dists)
            # convert from upper-triangular matrix to square matrix
            K = squareform(K)
            np.fill_diagonal(K, 1)
        else:
            if eval_gradient:
                raise ValueError("Gradient can only be evaluated when Y is None.")
            dists = cdist(X / length_scale, Y / length_scale,metric='sqeuclidean')
            K = np.exp(-.5 * dists)

        if eval_gradient:
            if self.hyperparameter_length_scale.fixed:
                # Hyperparameter l kept fixed
                return K, np.empty((X.shape[0], X.shape[0], 0))
            elif not self.anisotropic or length_scale.shape[0] == 1:
                K_gradient = (K * squareform(dists))[:, :, np.newaxis]
                return K, K_gradient
            elif self.anisotropic:
                # We need to recompute the pairwise dimension-wise distances
                K_gradient = (X[:, np.newaxis, :] - X[np.newaxis, :, :]) ** 2 / (length_scale ** 2)
                K_gradient *= K[..., np.newaxis]
                return K, K_gradient
        else:
            return K

    def __repr__(self):
        if self.anisotropic:
            return "{0}(length_scale=[{1}])".format(self.__class__.__name__, ", ".join(map("{0:.3g}".format,self.length_scale)))
        else:  # isotropic
            return "{0}(length_scale={1:.3g})".format(self.__class__.__name__, np.ravel(self.length_scale)[0])
    
#    def output(input1):
#        if input1 > 0.5:
#            o = 1
#        else:
#            o = -1
#        return o
            
        
StationaryKernelMixin = 1.0
NormalizedKernelMixin = 1.0
Kernel = 1.0
o = 0

def output(input1):
    if input1 > 0.5:
        o = 1
    else:
        o = -1
    return o

rbf_example = RBF()#StationaryKernelMixin, NormalizedKernelMixin, Kernel)
print(rbf_example.length_scale)
print(rbf_example.length_scale_bounds)
print(rbf_example.hyperparameter_length_scale())
print(rbf_example.anisotropic())
#rbf_example.output()
output_example = output(1)#rbf_example.length_scale())
print(output_example)










