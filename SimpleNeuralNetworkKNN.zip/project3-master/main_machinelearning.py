#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  8 16:48:54 2019

@author: alj0032
"""

'''
%matplotlib qt
#when you want graphs in a separate window and

%matplotlib inline
#when you want an inline plot
'''
from IPython import get_ipython
#get_ipython().run_line_magic('reset','-f')
#get_ipython().run_line_magic('run rls_7by7')
get_ipython().run_line_magic('matplotlib', 'qt')
#get_ipython().run_line_magic('matplotlib', 'inline')

import os
import random
import sys
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import time
import sklearn
from sklearn.svm import SVC
from sklearn.datasets import load_iris
from sklearn import svm
from sklearn import datasets
from sklearn import random_projection

data = np.array([[np.ones((1,10)) + random.gauss(0,1)],[np.ones((1,10))]])#np.sin(t*2*np.pi))
print(data[0][0])
np.shape(data)

# Kohonen Clustering 






# SVM (Support Vector Machine)

from sklearn.neural_network import MLPClassifier
X = [[0., 0.], [1., 1.]]
y = [0, 1]
clf = MLPClassifier(solver='lbfgs', alpha=1e-5,
                    hidden_layer_sizes=(5, 2), random_state=1)

clf.fit(X, y)                         

clf.predict([[1., 2.]])

clf.predict([[0., 0.]])






